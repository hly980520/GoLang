---
name: Add support for a specific file format
about: Use this issue template when the library lacks support for a file format.
title: Add support for X file format
labels: enhancement

---

1) Specify the MIME type and extension for which to add support
...
2) Share an example file
...
3) Optionally, add a reference to the specification of the file format.
...
